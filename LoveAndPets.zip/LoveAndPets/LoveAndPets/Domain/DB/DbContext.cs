﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace LoveAndPets.Domain.DB
{
    public class DbContext
    {
    }
}
