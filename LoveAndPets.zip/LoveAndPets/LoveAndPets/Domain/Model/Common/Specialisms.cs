﻿using LoveAndPets.Model.Common;

namespace LoveAndPets.Domain.Model.Common
{
    public class Specialisms : Entity
    {

        /// <summary>
        /// название специализации врача
        /// </summary>
        public string SpecialismName { get; set; }
    }
}
